from django.shortcuts import render
from django.http import HttpResponse


def home(request):
    return render(request, "SDP1.html")


def reg(request):
    return render(request, "register.html")


def login(request):
    return render(request, "login.html")


def veh(request):
    return render(request, "vehicles.html")
